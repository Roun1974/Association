<?php

namespace Container24duwvk;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder2012b = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerfc0e3 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesa6f79 = [
        
    ];

    public function getConnection()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getConnection', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getMetadataFactory', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getExpressionBuilder', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'beginTransaction', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getCache', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getCache();
    }

    public function transactional($func)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'transactional', array('func' => $func), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'wrapInTransaction', array('func' => $func), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'commit', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->commit();
    }

    public function rollback()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'rollback', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getClassMetadata', array('className' => $className), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'createQuery', array('dql' => $dql), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'createNamedQuery', array('name' => $name), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'createQueryBuilder', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'flush', array('entity' => $entity), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'clear', array('entityName' => $entityName), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->clear($entityName);
    }

    public function close()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'close', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->close();
    }

    public function persist($entity)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'persist', array('entity' => $entity), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'remove', array('entity' => $entity), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'refresh', array('entity' => $entity), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'detach', array('entity' => $entity), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'merge', array('entity' => $entity), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getRepository', array('entityName' => $entityName), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'contains', array('entity' => $entity), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getEventManager', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getConfiguration', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'isOpen', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getUnitOfWork', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getProxyFactory', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'initializeObject', array('obj' => $obj), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'getFilters', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'isFiltersStateClean', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'hasFilters', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return $this->valueHolder2012b->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerfc0e3 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder2012b) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder2012b = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder2012b->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, '__get', ['name' => $name], $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        if (isset(self::$publicPropertiesa6f79[$name])) {
            return $this->valueHolder2012b->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2012b;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder2012b;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2012b;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder2012b;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, '__isset', array('name' => $name), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2012b;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder2012b;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, '__unset', array('name' => $name), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2012b;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder2012b;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, '__clone', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        $this->valueHolder2012b = clone $this->valueHolder2012b;
    }

    public function __sleep()
    {
        $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, '__sleep', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;

        return array('valueHolder2012b');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerfc0e3 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerfc0e3;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerfc0e3 && ($this->initializerfc0e3->__invoke($valueHolder2012b, $this, 'initializeProxy', array(), $this->initializerfc0e3) || 1) && $this->valueHolder2012b = $valueHolder2012b;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder2012b;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder2012b;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
